#!/bin/sh
python3 -m unittest odsiRC4/tests/*_test.py